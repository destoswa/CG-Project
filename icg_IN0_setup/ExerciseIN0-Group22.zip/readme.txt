ExerciseIN0-Group22

---------------------
1.Set background color

	used the built-in color picker in code to choose a colour

2.Modify the scene

	fairly straightforward instructions, used the color picker from previous exercise to find a new color for new material
	the png file basic-sphere shows the end result of exercises 1 and 2.

3.Custom mesh

	built a star-shaped mesh in Blender by adding new vertices in the mesh.
	struggled a little bit with object orientation, since .obj automatically applies default axes.
	since the mesh is bigger than expected, we removed the ground plane for better visibility.